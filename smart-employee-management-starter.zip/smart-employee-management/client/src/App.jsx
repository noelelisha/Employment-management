import { Link, Route, Routes } from "react-router-dom";

function Dashboard() {
  return (
    <main className="container py-5">
      <p className="eyebrow">SMART WORKPLACE</p>
      <h1>Employee Management & Learning</h1>
      <p className="text-secondary">
        Manage your work, develop new skills, and build confidence one day at a time.
      </p>
      <div className="row g-3 mt-4">
        {[
          ["30-Day Journey", "Daily activities to help new recruits settle in."],
          ["Learning", "Courses for communication, teamwork, and project skills."],
          ["Projects", "Track assignments, deadlines, and team progress."]
        ].map(([title, description]) => (
          <div className="col-md-4" key={title}>
            <section className="feature-card h-100">
              <h2>{title}</h2>
              <p>{description}</p>
            </section>
          </div>
        ))}
      </div>
      <Link className="btn btn-primary mt-4" to="/journey">View development journey</Link>
    </main>
  );
}

function Journey() {
  return (
    <main className="container py-5">
      <Link to="/">← Dashboard</Link>
      <h1 className="mt-3">30-Day New Recruit Journey</h1>
      <p className="text-secondary">Starter page: connect this view to employee task assignments.</p>
      <ol className="journey-list">
        <li><strong>Week 1:</strong> Company orientation</li>
        <li><strong>Week 2:</strong> Communication and teamwork</li>
        <li><strong>Week 3:</strong> Practical work and project handling</li>
        <li><strong>Week 4:</strong> Presentation and confidence</li>
      </ol>
    </main>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/journey" element={<Journey />} />
    </Routes>
  );
}
