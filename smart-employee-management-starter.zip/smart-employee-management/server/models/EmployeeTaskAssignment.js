import mongoose from "mongoose";

const employeeTaskAssignmentSchema = new mongoose.Schema({
  template: { type: mongoose.Schema.Types.ObjectId, ref: "ConfidenceTaskTemplate", required: true },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  assignedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  dueDate: { type: Date },
  status: {
    type: String,
    enum: ["pending", "in-progress", "submitted", "completed"],
    default: "pending"
  },
  submissionText: { type: String, default: "" },
  feedback: { type: String, default: "" },
  completedAt: { type: Date }
}, { timestamps: true });

export default mongoose.model("EmployeeTaskAssignment", employeeTaskAssignmentSchema);
