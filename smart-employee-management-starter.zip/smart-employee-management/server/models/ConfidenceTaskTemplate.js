import mongoose from "mongoose";

const confidenceTaskTemplateSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  instructions: { type: String, default: "" },
  department: { type: String, default: "All" },
  dayNumber: { type: Number, min: 1, max: 30, required: true },
  difficulty: { type: String, enum: ["beginner", "intermediate", "advanced"], default: "beginner" }
}, { timestamps: true });

export default mongoose.model("ConfidenceTaskTemplate", confidenceTaskTemplateSchema);
